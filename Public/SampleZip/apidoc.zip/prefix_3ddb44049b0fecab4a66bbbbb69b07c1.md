**简要描述：** 

- 获取全国省份数据

**请求URL：** 
- ` http://xx.com/api/geograph/province `
  
**请求方式：**
- GET 

**参数：** 

无

 **返回示例**
``` 
{
    "error_code": 0,
    "data": [
        {
            "id": "1",
            "code": "11",
            "parentid": "0",
            "name": "北京市",
            "level": "1"
        },
        {
            "id": "636",
            "code": "13",
            "parentid": "0",
            "name": "河北省",
            "level": "1"
        },
     .....     
    ]
}

```
 **返回参数说明** 

无

 **备注** 

- 更多返回错误代码请看首页的错误代码描述


